const sb = (window.SUPABASE_URL && window.SUPABASE_ANON_KEY && !window.SUPABASE_URL.includes('YOUR_'))
  ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY)
  : null;

const FALLBACK = [
  {id:'local-1',name:'SADEE SOLUTIONS — App & Website Package',category:'Development',price:1000,price_note:'Inbox for final price',image_url:'assets/sadee-solutions.jpg',description:'Custom app and website development package for digital businesses.',features:['Custom mobile applications','Custom websites','Cloud solutions','API integration','Digital innovation'],featured:true,active:true},
  {id:'local-2',name:'SADEE SENSITIVE PRO',category:'Gaming',price:1000,price_note:'Lifetime',image_url:'assets/sadee-sensitive-pro.png',description:'Free Fire sensitivity tool for creating device-based sensitivity profiles.',features:['Free Fire sensitivity profiles','Device-based setup','Custom presets','Lifetime access'],featured:true,active:true},
  {id:'local-3',name:'SADEE X DIMA OPTIMIZER',category:'Gaming',price:500,price_note:'7 day key • 1 month Rs.1000 • Lifetime Rs.2200',image_url:'assets/sadee-x-dima-optimizer.png',description:'Optimization system with device information, RAM/storage utilities, game tools and activation-key access.',features:['7 day key — Rs.500','1 month — Rs.1000','Lifetime — Rs.2200','Device information','RAM / storage tools','Game optimization tools'],featured:true,active:true}
];

let products=[...FALLBACK], settings=null;
const $=s=>document.querySelector(s);
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const imgFor=p=>(p.image_url||p.image||'').trim()||(String(p.name).includes('SENSITIVE PRO')?'assets/sadee-sensitive-pro.png':String(p.name).includes('OPTIMIZER')?'assets/sadee-x-dima-optimizer.png':'assets/sadee-solutions.jpg');
const money=p=>p.price_note?.toLowerCase().includes('inbox')?`Rs. ${Number(p.price||0).toLocaleString()}+`:`Rs. ${Number(p.price||0).toLocaleString()}`;
const setting=(key,fallback='')=>settings && settings[key]!=null ? settings[key] : fallback;

function applySettings(){
  if(!settings)return;
  document.title=setting('site_name','SADEE SOLUTIONS — Digital Store');
  const desc=setting('seo_description','SADEE SOLUTIONS — apps, websites, gaming tools and digital products.');
  document.querySelector('meta[name="description"]')?.setAttribute('content',desc);
  const brandName=$('.brand span:last-child'); if(brandName) brandName.innerHTML=esc(setting('site_name','SADEE SOLUTIONS')).replace('SOLUTIONS','<b>SOLUTIONS</b>');
  const heroEyebrow=$('.hero .eyebrow'); if(heroEyebrow)heroEyebrow.textContent=setting('hero_eyebrow','SADEE SOLUTIONS • DIGITAL STORE');
  const heroTitle=$('.hero h1'); if(heroTitle){const parts=setting('hero_title','YOUR NEXT|DIGITAL EDGE.').split('|');heroTitle.innerHTML=esc(parts[0]||'YOUR NEXT')+'<br><em>'+esc(parts.slice(1).join('|')||'DIGITAL EDGE.')+'</em>';}
  const heroText=$('.hero-copy>p');if(heroText)heroText.textContent=setting('hero_text','Apps, websites, gaming tools and custom digital solutions. Choose a product, view the full details and order directly through WhatsApp.');
  const aboutTitle=$('#about h2');if(aboutTitle){const parts=setting('about_title','Build. Launch.|Upgrade.').split('|');aboutTitle.innerHTML=esc(parts[0]||'Build. Launch.')+'<br><em>'+esc(parts.slice(1).join('|')||'Upgrade.')+'</em>';}
  const aboutText=$('#about p');if(aboutText)aboutText.textContent=setting('about_text','SADEE SOLUTIONS creates mobile applications, custom websites, cloud-connected systems and digital tools. Product details, prices, images and availability are managed from a private admin panel.');
  const contactTitle=$('#contact h2');if(contactTitle)contactTitle.textContent=setting('contact_title','Need a custom solution?');
  const contactText=$('#contact p');if(contactText)contactText.textContent=setting('contact_text','Tell SADEE what you want to build or which product you need.');
  const footer=document.querySelector('footer');if(footer){const s1=footer.children[0],s2=footer.children[1];if(s1)s1.textContent=setting('footer_left','© 2026 SADEE SOLUTIONS');if(s2)s2.textContent=setting('footer_right','APP • WEBSITE • DIGITAL TOOLS');}
  const heroVideo=$('.hero-media video');if(heroVideo){heroVideo.src=setting('hero_video_url','assets/showcase.mp4');heroVideo.style.display=setting('hero_video_enabled',true)?'block':'none';}
  const logo=setting('logo_image_url','');if(logo){const mark=$('.brand-mark');if(mark)mark.innerHTML=`<img src="${esc(logo)}" alt="">`;}
  const root=document.documentElement;if(setting('accent_color',''))root.style.setProperty('--red',setting('accent_color'));if(setting('background_color',''))root.style.setProperty('--bg',setting('background_color'));
  const ann=setting('announcement','');let bar=$('#announcementBar');if(setting('announcement_active',false)&&ann){if(!bar){bar=document.createElement('div');bar.id='announcementBar';bar.className='announcement-bar';document.body.prepend(bar);}bar.textContent=ann;}else if(bar)bar.remove();
  if(setting('maintenance',false)){document.body.classList.add('maintenance-mode');if(!$('#maintenanceBox')){const x=document.createElement('div');x.id='maintenanceBox';x.className='maintenance-box';x.innerHTML=`<b>STORE MAINTENANCE</b><span>${esc(setting('maintenance_message','We are updating the store. Please check again soon.'))}</span>`;document.body.appendChild(x);}}
}

function render(){
  const q=$('#search').value.toLowerCase().trim(),cat=$('#category').value;
  const list=products.filter(p=>p.active!==false&&(!q||`${p.name} ${p.description||''} ${p.category||''}`.toLowerCase().includes(q))&&(!cat||p.category===cat));
  $('#status').textContent=`${list.length} product${list.length===1?'':'s'} available`;
  $('#products').innerHTML=list.length?list.map(p=>`<article class="card"><div class="card-img"><img loading="lazy" src="${esc(imgFor(p))}" alt="${esc(p.name)}" onerror="this.src='assets/sadee-solutions.jpg'">${p.featured?'<span class="badge">FEATURED</span>':''}<span class="card-index">${String(p.id).slice(0,4).toUpperCase()}</span></div><div class="card-body"><span class="eyebrow">${esc(p.category||'DIGITAL PRODUCT')}</span><h3>${esc(p.name)}</h3><p class="desc">${esc(p.description||'Premium digital product from SADEE SOLUTIONS.')}</p><div class="price-row"><div class="price">${money(p)}</div><span class="available">● AVAILABLE</span></div><button class="btn primary view-btn" data-id="${esc(p.id)}">VIEW & BUY <span>↗</span></button></div></article>`).join(''):'<div class="empty"><b>NO PRODUCTS FOUND</b><span>Try another search or category.</span></div>';
}

function openDetail(id){
  const p=products.find(x=>String(x.id)===String(id));if(!p)return;
  const download=p.download_enabled&&p.download_url;
  const payment=setting('payment_enabled',false)&&setting('payment_image_url','');
  $('#detail').innerHTML=`<div class="detail-grid"><div><div class="detail-image"><img src="${esc(imgFor(p))}" alt="${esc(p.name)}" onerror="this.src='assets/sadee-solutions.jpg'"></div>${payment?`<div class="payment-box"><b>PAYMENT INFO</b><img src="${esc(setting('payment_image_url'))}" alt="Payment information"></div>`:''}</div><div class="detail-copy"><span class="status-pill">● ${p.active!==false?'AVAILABLE':'UNAVAILABLE'}</span><span class="eyebrow">${esc(p.category||'DIGITAL PRODUCT')}</span><h2>${esc(p.name)}</h2><div class="detail-price">${money(p)} <small>${esc(p.price_note||'')}</small></div><p>${esc(p.description||'')}</p><ul class="feature-list">${(p.features||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul>${p.version?`<div class="version-line">VERSION: <b>${esc(p.version)}</b></div>`:''}<div class="order-fields"><input id="customerName" placeholder="Your name (optional)" autocomplete="name"><input id="customerPhone" placeholder="Phone (optional)" inputmode="tel" autocomplete="tel"></div><div class="detail-actions"><button class="btn primary buy-btn" id="buyBtn">BUY NOW — WHATSAPP ↗</button>${download?`<a class="btn ghost" href="${esc(p.download_url)}" download>DOWNLOAD APK ↓</a>`:''}</div><small class="order-note">${esc(setting('key_message',p.requires_key?'App use requires an activation key.':'Your order is recorded for SADEE before WhatsApp opens.'))}</small></div></div>`;
  $('#drawer').classList.add('show');$('#drawer').setAttribute('aria-hidden','false');document.body.classList.add('modal-open');$('#buyBtn').onclick=()=>placeOrder(p);
}

async function placeOrder(p){
  const name=$('#customerName')?.value.trim()||'',phone=$('#customerPhone')?.value.trim()||'',btn=$('#buyBtn');btn.disabled=true;btn.textContent='PREPARING ORDER…';
  if(sb){const {error}=await sb.from('orders').insert({product_id:p.id,product_name:p.name,price:Number(p.price||0),customer_name:name,customer_phone:phone,source:'whatsapp'});if(error)console.warn('Order record failed:',error.message);}
  const msg=`Hello SADEE SOLUTIONS 👋\n\nI want to order:\n*${p.name}*\nPrice: ${money(p)}\n${name?`Name: ${name}\n`:''}${phone?`Phone: ${phone}\n`:''}\nPlease send me the payment/order details.`;
  window.open(`https://wa.me/${window.WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`,'_blank','noopener');btn.disabled=false;btn.textContent='ORDER SENT — WHATSAPP ↗';
}

async function loadStore(){
  if(!sb){render();return;}
  const [sr,pr]=await Promise.all([sb.from('site_settings').select('*').order('id',{ascending:true}).limit(1).maybeSingle(),sb.from('products').select('*').order('created_at',{ascending:false})]);
  if(!sr.error&&sr.data)settings=sr.data; else if(sr.error)console.warn('Settings unavailable:',sr.error.message);
  if(!pr.error&&pr.data?.length){products=pr.data;} else if(pr.error)console.warn('Products unavailable:',pr.error.message);
  applySettings();
  const cats=[...new Set(products.map(x=>x.category).filter(Boolean))].sort();$('#category').innerHTML='<option value="">All categories</option>'+cats.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
  render();
}

$('#products').addEventListener('click',e=>{const b=e.target.closest('.view-btn');if(b)openDetail(b.dataset.id);});
$('#search').addEventListener('input',render);$('#category').addEventListener('change',render);
$('#closeDrawer').onclick=()=>{$('#drawer').classList.remove('show');$('#drawer').setAttribute('aria-hidden','true');document.body.classList.remove('modal-open');};
$('#drawer').addEventListener('click',e=>{if(e.target.id==='drawer')$('#closeDrawer').click();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#drawer').classList.contains('show'))$('#closeDrawer').click();});
const menuBtn=$('#menuBtn'),nav=$('#mainNav');menuBtn.addEventListener('click',()=>{const open=document.querySelector('.topbar').classList.toggle('nav-open');menuBtn.setAttribute('aria-expanded',String(open));});nav.addEventListener('click',()=>{document.querySelector('.topbar').classList.remove('nav-open');menuBtn.setAttribute('aria-expanded','false');});
loadStore();

-- SADEE SOLUTIONS FULL CONTROL ADMIN UPGRADE
-- Run this ONCE in Supabase SQL Editor for the existing project.
create extension if not exists pgcrypto;

alter table public.products add column if not exists version text default '';
alter table public.products add column if not exists download_url text default '';
alter table public.products add column if not exists download_enabled boolean default false;
alter table public.products add column if not exists requires_key boolean default true;

create table if not exists public.site_settings (
 id bigint primary key default 1,
 site_name text default 'SADEE SOLUTIONS', hero_eyebrow text default 'SADEE SOLUTIONS • DIGITAL STORE', hero_title text default 'YOUR NEXT DIGITAL EDGE.', hero_text text default '', announcement text default '', announcement_active boolean default false, maintenance boolean default false,
 about_title text default 'Build. Launch. Upgrade.', about_text text default '', contact_title text default 'Need a custom solution?', contact_text text default '',
 whatsapp_number text default '94768472404', whatsapp_display text default '+94 76 847 2404', ez_cash_number text default '0760625028', whatsapp_channel text default '',
 shop_label text default 'Shop', about_label text default 'About', contact_label text default 'Contact', footer_left text default '© 2026 SADEE SOLUTIONS', footer_right text default 'APP • WEBSITE • DIGITAL TOOLS',
 stat1 text default '24/7 Order Chat', stat2 text default '3+ Digital Products', stat3 text default '100% Mobile Ready', hero_video_url text default '', logo_image_url text default '', orders_enabled boolean default true, downloads_enabled boolean default true, key_required boolean default true, updated_at timestamptz default now()
);
insert into public.site_settings(id) values(1) on conflict(id) do nothing;

create table if not exists public.license_keys (
 id uuid primary key default gen_random_uuid(), key_code text unique not null, product_id uuid references public.products(id) on delete set null, product_name text default '', plan text default '7_days', customer_name text default '', customer_phone text default '', max_devices integer default 1, active boolean default true, revoked boolean default false, used_at timestamptz, expires_at timestamptz, device_count integer default 0, device_info jsonb default '{}'::jsonb, created_at timestamptz default now(), updated_at timestamptz default now()
);

create table if not exists public.app_updates (
 id bigint primary key default 1, app_name text default 'SADEE X DIMA OPTIMIZER', version text default '', apk_url text default '', min_version text default '', message text default '', force_update boolean default false, active boolean default false, updated_at timestamptz default now()
);
insert into public.app_updates(id) values(1) on conflict(id) do nothing;

-- Ensure admin check is safe and does not recurse through admin_users RLS.
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.admin_users au where lower(au.email)=lower(coalesce(auth.jwt()->>'email','')));
$$;
grant usage on schema public to authenticated;
grant execute on function public.is_admin() to authenticated;

-- Required grants.
grant select on public.products to anon, authenticated;
grant select,insert,update,delete on public.products to authenticated;
grant select,insert on public.orders to anon, authenticated;
grant select,update,delete on public.orders to authenticated;
grant select,insert,update,delete on public.license_keys to authenticated;
grant select on public.site_settings to anon, authenticated;
grant select,insert,update on public.site_settings to authenticated;
grant select on public.app_updates to anon, authenticated;
grant select,insert,update on public.app_updates to authenticated;

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.license_keys enable row level security;
alter table public.site_settings enable row level security;
alter table public.app_updates enable row level security;

-- Replace common policies. This fixes the current "permission denied for table orders" error.
drop policy if exists "public can read active products" on public.products;
drop policy if exists "admins can manage products" on public.products;
create policy "public can read active products" on public.products for select using (active=true or public.is_admin());
create policy "admins can manage products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public can create orders" on public.orders;
drop policy if exists "admins can read orders" on public.orders;
drop policy if exists "admins can manage orders" on public.orders;
create policy "public can create orders" on public.orders for insert to anon,authenticated with check (true);
create policy "admins can read orders" on public.orders for select to authenticated using (public.is_admin());
create policy "admins can manage orders" on public.orders for update,delete to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admins can manage license keys" on public.license_keys;
create policy "admins can manage license keys" on public.license_keys for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public can read site settings" on public.site_settings;
drop policy if exists "admins can manage site settings" on public.site_settings;
create policy "public can read site settings" on public.site_settings for select using (true);
create policy "admins can manage site settings" on public.site_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public can read app updates" on public.app_updates;
drop policy if exists "admins can manage app updates" on public.app_updates;
create policy "public can read app updates" on public.app_updates for select using (true);
create policy "admins can manage app updates" on public.app_updates for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Admin identity. Add your existing login email if this is the account shown in Admin.
insert into public.admin_users(email) values ('sadeexdima@gmail.com') on conflict(email) do nothing;

-- Storage for product media.
insert into storage.buckets(id,name,public) values('product-media','product-media',true) on conflict(id) do update set public=true;
drop policy if exists "public can view product media" on storage.objects;
drop policy if exists "admins can upload product media" on storage.objects;
drop policy if exists "admins can update product media" on storage.objects;
drop policy if exists "admins can delete product media" on storage.objects;
create policy "public can view product media" on storage.objects for select using(bucket_id='product-media');
create policy "admins can upload product media" on storage.objects for insert to authenticated with check(bucket_id='product-media' and public.is_admin());
create policy "admins can update product media" on storage.objects for update to authenticated using(bucket_id='product-media' and public.is_admin()) with check(bucket_id='product-media' and public.is_admin());
create policy "admins can delete product media" on storage.objects for delete to authenticated using(bucket_id='product-media' and public.is_admin());

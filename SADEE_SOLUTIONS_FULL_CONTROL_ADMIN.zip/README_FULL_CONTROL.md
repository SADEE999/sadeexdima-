# SADEE SOLUTIONS — Full Control Admin Upgrade

## 1. Supabase
Open Supabase Dashboard → SQL Editor and run:
`supabase_full_control.sql`

This adds the website editor, license keys, app updates, download controls and fixes the admin Orders RLS policy.

## 2. GitHub
Replace the repository files with this package and commit to `main`.
The included `.github/workflows/main.yml` extracts a root ZIP when present, builds `dist`, disables mobile pinch zoom and uploads the build artifact.

## 3. Netlify
Keep the existing GitHub-connected Netlify project. If the repository contains the website ZIP at root, use build command:
`rm -rf dist && mkdir dist && unzip -o *.zip -d dist`
Publish directory: `dist`.

Admin URL:
`/admin/`

Public site has no admin link.

# SADEE SOLUTIONS PRO MAX ADVANCED

Private admin-controlled digital store.

## Public site
The public site contains only the customer-facing storefront. The admin panel is separate at `/admin/` and is not linked from the public navigation.

## Admin
Login at `/admin/` using a Supabase Authentication user that also exists in `public.admin_users`.

Admin controls include:
- Add/edit/delete/hide/show/duplicate products
- Product prices, descriptions, features and images
- Featured products
- Order list and order status
- CSV order export
- Store announcements
- Maintenance mode
- Hero/about/contact content
- WhatsApp, eZ Cash and channel details
- Navigation labels and footer text
- Hero stats and video URL
- Logo and favicon URL
- SEO description
- Accent/background colors
- Optional custom CSS

## Supabase
Run `supabase.sql` in Supabase SQL Editor once. Never put a Supabase service-role key in `config.js`.

## GitHub Pages
Put this ZIP in the repository root. The workflow extracts the ZIP automatically and deploys the extracted site.

For the most reliable first deployment, enable **Settings → Pages → Build and deployment → Source → GitHub Actions** once. GitHub's official documentation requires Pages to be configured for Actions deployments. The workflow also supports automatic first-time enablement when a `PAGES_TOKEN` repository secret is supplied.

`PAGES_TOKEN` should be a GitHub Personal Access Token with the permissions required by `actions/configure-pages` to enable Pages.

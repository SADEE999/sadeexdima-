-- SADEE SOLUTIONS FULL CONTROL UPGRADE
-- Run once in Supabase SQL Editor. Safe for the existing store: adds missing columns/tables and policies.
create extension if not exists pgcrypto;

alter table public.products add column if not exists version text default '';
alter table public.products add column if not exists download_url text default '';
alter table public.products add column if not exists download_enabled boolean default false;
alter table public.products add column if not exists requires_key boolean default true;
alter table public.products add column if not exists updated_at timestamptz default now();
alter table public.orders add column if not exists status text default 'new';
alter table public.orders add column if not exists source text default 'whatsapp';

create table if not exists public.site_settings (
 id integer primary key default 1 check (id=1),
 site_name text default 'SADEE SOLUTIONS', hero_eyebrow text default 'SADEE SOLUTIONS • DIGITAL STORE', hero_title text default 'YOUR NEXT|DIGITAL EDGE.', hero_text text default '', about_title text default 'Build. Launch.|Upgrade.', about_text text default '', footer_text text default '© 2026 SADEE SOLUTIONS',
 whatsapp_number text default '94768472404', channel_url text default '', ez_cash_number text default '',
 video_url text default 'assets/showcase.mp4', video_enabled boolean default true,
 payment_image_url text default 'assets/payment-method.png', payment_enabled boolean default true,
 announcement text default '', announcement_enabled boolean default false,
 maintenance_mode boolean default false, updated_at timestamptz default now()
);
alter table public.site_settings add column if not exists site_name text default 'SADEE SOLUTIONS';
alter table public.site_settings add column if not exists hero_eyebrow text default 'SADEE SOLUTIONS • DIGITAL STORE';
alter table public.site_settings add column if not exists hero_title text default 'YOUR NEXT|DIGITAL EDGE.';
alter table public.site_settings add column if not exists hero_text text default '';
alter table public.site_settings add column if not exists about_title text default 'Build. Launch.|Upgrade.';
alter table public.site_settings add column if not exists about_text text default '';
alter table public.site_settings add column if not exists footer_text text default '© 2026 SADEE SOLUTIONS';
alter table public.site_settings add column if not exists whatsapp_number text default '94768472404';
alter table public.site_settings add column if not exists channel_url text default '';
alter table public.site_settings add column if not exists ez_cash_number text default '';
alter table public.site_settings add column if not exists video_url text default 'assets/showcase.mp4';
alter table public.site_settings add column if not exists video_enabled boolean default true;
alter table public.site_settings add column if not exists payment_image_url text default 'assets/payment-method.png';
alter table public.site_settings add column if not exists payment_enabled boolean default true;
alter table public.site_settings add column if not exists announcement text default '';
alter table public.site_settings add column if not exists announcement_enabled boolean default false;
alter table public.site_settings add column if not exists maintenance_mode boolean default false;
alter table public.site_settings add column if not exists updated_at timestamptz default now();
insert into public.site_settings(id) values(1) on conflict(id) do nothing;
update public.site_settings set payment_image_url=coalesce(nullif(payment_image_url,''),'assets/payment-method.png') where id=1;

create table if not exists public.license_keys (
 id uuid primary key default gen_random_uuid(), product_id uuid references public.products(id) on delete set null,
 product_name text default '', key_code text unique not null, plan text not null default '7 Days', duration_days integer,
 status text not null default 'active', customer_name text default '', customer_phone text default '', device_id text default '', max_devices integer default 1,
 used_at timestamptz, expires_at timestamptz, created_at timestamptz default now(), updated_at timestamptz default now()
);
create index if not exists license_keys_key_idx on public.license_keys(key_code);

create table if not exists public.app_updates (
 id uuid primary key default gen_random_uuid(), product_id uuid references public.products(id) on delete set null,
 version text not null default '', update_title text default '', update_message text default '', apk_url text default '', force_update boolean default false,
 active boolean default true, created_at timestamptz default now(), updated_at timestamptz default now()
);

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.admin_users au where lower(au.email)=lower(coalesce(auth.jwt()->>'email','')));
$$;
grant execute on function public.is_admin() to authenticated;

grant select on public.products to anon,authenticated;
grant select,insert,update,delete on public.products to authenticated;
grant select,insert on public.orders to anon,authenticated;
grant select,update,delete on public.orders to authenticated;
grant select on public.site_settings to anon,authenticated;
grant select,insert,update,delete on public.site_settings to authenticated;
grant select,insert,update,delete on public.license_keys to authenticated;
grant select on public.app_updates to anon,authenticated;
grant select,insert,update,delete on public.app_updates to authenticated;

alter table public.products enable row level security; alter table public.orders enable row level security; alter table public.site_settings enable row level security; alter table public.license_keys enable row level security; alter table public.app_updates enable row level security;

drop policy if exists "public can read active products" on public.products;
create policy "public can read active products" on public.products for select using(active=true or public.is_admin());
drop policy if exists "admins can manage products" on public.products;
create policy "admins can manage products" on public.products for all to authenticated using(public.is_admin()) with check(public.is_admin());

drop policy if exists "public can create orders" on public.orders;
create policy "public can create orders" on public.orders for insert to anon,authenticated with check(true);
drop policy if exists "admins can read orders" on public.orders;
create policy "admins can read orders" on public.orders for select to authenticated using(public.is_admin());
drop policy if exists "admins can manage orders" on public.orders;
create policy "admins can manage orders" on public.orders for update,delete to authenticated using(public.is_admin()) with check(public.is_admin());

drop policy if exists "public can read site settings" on public.site_settings;
create policy "public can read site settings" on public.site_settings for select to anon,authenticated using(true);
drop policy if exists "admins can manage site settings" on public.site_settings;
create policy "admins can manage site settings" on public.site_settings for all to authenticated using(public.is_admin()) with check(public.is_admin());

drop policy if exists "admins can manage license keys" on public.license_keys;
create policy "admins can manage license keys" on public.license_keys for all to authenticated using(public.is_admin()) with check(public.is_admin());

drop policy if exists "public can read active updates" on public.app_updates;
create policy "public can read active updates" on public.app_updates for select to anon,authenticated using(active=true);
drop policy if exists "admins can manage updates" on public.app_updates;
create policy "admins can manage updates" on public.app_updates for all to authenticated using(public.is_admin()) with check(public.is_admin());

insert into storage.buckets(id,name,public) values('site-media','site-media',true) on conflict(id) do update set public=true;
insert into storage.buckets(id,name,public) values('product-media','product-media',true) on conflict(id) do update set public=true;
drop policy if exists "public can view site media" on storage.objects;
create policy "public can view site media" on storage.objects for select using(bucket_id='site-media');
drop policy if exists "admins can upload site media" on storage.objects;
create policy "admins can upload site media" on storage.objects for insert to authenticated with check(bucket_id='site-media' and public.is_admin());
drop policy if exists "admins can update site media" on storage.objects;
create policy "admins can update site media" on storage.objects for update to authenticated using(bucket_id='site-media' and public.is_admin()) with check(bucket_id='site-media' and public.is_admin());
drop policy if exists "admins can delete site media" on storage.objects;
create policy "admins can delete site media" on storage.objects for delete to authenticated using(bucket_id='site-media' and public.is_admin());
drop policy if exists "public can view product media" on storage.objects;
create policy "public can view product media" on storage.objects for select using(bucket_id='product-media');
drop policy if exists "admins can upload product media" on storage.objects;
create policy "admins can upload product media" on storage.objects for insert to authenticated with check(bucket_id='product-media' and public.is_admin());
drop policy if exists "admins can update product media" on storage.objects;
create policy "admins can update product media" on storage.objects for update to authenticated using(bucket_id='product-media' and public.is_admin()) with check(bucket_id='product-media' and public.is_admin());
drop policy if exists "admins can delete product media" on storage.objects;
create policy "admins can delete product media" on storage.objects for delete to authenticated using(bucket_id='product-media' and public.is_admin());

-- Keep the existing admin account; normalize the known admin email if present.
update public.admin_users set email='sadeexdima@gmail.com' where lower(email)='sadeexdima@gmail.com' and email<>'sadeexdima@gmail.com';
insert into public.admin_users(email) values('sadeexdima@gmail.com') on conflict(email) do nothing;

-- Store payment poster supplied by the owner can be uploaded through Admin > Website Editor.

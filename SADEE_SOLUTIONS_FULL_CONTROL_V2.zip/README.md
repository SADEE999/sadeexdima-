# SADEE SOLUTIONS — Full Control Store

Netlify-ready static store + Supabase admin.

## Admin
Open `/admin/`. The public site has no admin link.

## Full controls
- Website text/hero/about/footer
- Showcase video URL or upload, enable/disable
- Payment image URL or upload, enable/disable
- Announcement + maintenance mode
- Products, images, prices, features
- APK/ZIP upload or download URL + Download button
- Requires-key/free-use flag and version
- License key generation/revoke
- App updates and force-update flag
- Orders and status changes
- Insights/export

Run `supabase.sql` once after deploying this version.
